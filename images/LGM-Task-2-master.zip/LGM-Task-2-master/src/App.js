import React from "react";
import GetUserData from "./components/gettingUserData";

function App() {
  return (
    <div className="App">
      <GetUserData />
    </div>
  );
}

export default App;
